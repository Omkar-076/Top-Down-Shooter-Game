#include"EntityManager.h"
#include"../entities/Bullet.h"
void EntityManager::createBullet(ShootRequest shootRequest) {
	Bullet bullet(shootRequest);
	bulletVector.push_back(bullet);
}
void EntityManager::updateBullets(float deltaTime) {
	for (int i = 0; i < bulletVector.size(); i++)
	{
		bulletVector[i].update(deltaTime);
	}
}
void EntityManager::renderBullets(SDL_Renderer* renderer) {
	for (int i = 0; i < bulletVector.size(); i++)
	{
		bulletVector[i].render(renderer);
	}
}