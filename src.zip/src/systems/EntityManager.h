#pragma once
#include<iostream>
#include<vector>
#include"../entities/ShootRequest.h"
#include"../entities/Bullet.h"
class EntityManager {
	std::vector<Bullet> bulletVector;
public:
	void createBullet(ShootRequest shootRequest);
	void updateBullets(float deltaTime);
	void renderBullets(SDL_Renderer* renderer);
};